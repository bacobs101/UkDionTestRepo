import React from 'react'

export default function Success() {
    return (
        <div>
            
        </div>
    )
}
